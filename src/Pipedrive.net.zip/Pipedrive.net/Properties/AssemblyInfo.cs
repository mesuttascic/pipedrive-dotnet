﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Pipedrive.Tests")]