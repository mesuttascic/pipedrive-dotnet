﻿namespace Pipedrive
{
    public static class AcceptHeaders
    {
        public const string Json = "application/json";
    }
}
