﻿namespace Pipedrive
{
    public class Option
    {
        public string Id { get; set; }

        public string Label { get; set; }
    }
}
