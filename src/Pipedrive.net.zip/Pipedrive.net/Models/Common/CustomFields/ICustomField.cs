﻿namespace Pipedrive
{
    public interface ICustomField
    {
    }
}
