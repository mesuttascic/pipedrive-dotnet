﻿namespace Pipedrive
{
    public enum Visibility
    {
        @private = 1,
        shared = 3
    }
}
