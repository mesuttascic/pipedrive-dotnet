﻿namespace Pipedrive
{
    public enum DealStatus
    {
        open,
        won,
        lost,
        deleted
    }
}
