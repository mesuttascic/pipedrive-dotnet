﻿namespace Pipedrive
{
    public interface IDealUpdateEntity
    {
        long Id { get; set; }
    }
}
