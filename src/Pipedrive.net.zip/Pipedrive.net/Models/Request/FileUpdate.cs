﻿namespace Pipedrive
{
    public class FileUpdate
    {
        public string Name { get; set; }

        public string Description { get; set; }
    }
}
