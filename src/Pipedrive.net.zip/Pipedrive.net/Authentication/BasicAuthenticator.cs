﻿using System;
using System.Diagnostics;
using System.Globalization;
using System.Text;
using Pipedrive.Helpers;

namespace Pipedrive.Internal
{
    class BasicAuthenticator : IAuthenticationHandler
    {
        /// <summary>
        /// ⚠ FOR INTERNAL USE ONLY. Pipedrive don't support Basic authentication.
        /// Authenticate a request using the basic access authentication scheme
        /// </summary>
        /// <param name="request">The request to authenticate</param>
        /// <param name="credentials">The credentials to attach to the request</param>
        public void Authenticate(IRequest request, Credentials credentials)
        {
            Ensure.ArgumentNotNull(request, nameof(request));
            Ensure.ArgumentNotNull(credentials, nameof(credentials));
            Ensure.ArgumentNotNull(credentials.Login, nameof(credentials.Login));
            Debug.Assert(credentials.Password != null, "It should be impossible for the password to be null");

            var header = string.Format(
                CultureInfo.InvariantCulture,
                "Basic {0}",
                Convert.ToBase64String(Encoding.UTF8.GetBytes(
                    string.Format(CultureInfo.InvariantCulture, "{0}:{1}", credentials.Login, credentials.Password))));

            request.Headers["Authorization"] = header;
        }
    }
}
